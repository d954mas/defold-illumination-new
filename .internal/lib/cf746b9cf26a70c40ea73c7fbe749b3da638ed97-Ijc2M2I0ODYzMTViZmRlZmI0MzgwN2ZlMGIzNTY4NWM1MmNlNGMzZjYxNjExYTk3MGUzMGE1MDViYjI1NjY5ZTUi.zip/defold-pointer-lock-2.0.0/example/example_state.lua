local M = {
    eye_pos = vmath.vector3(0, 170, 0),
    yaw = 270,
    pitch = 0
}

return M